class Routes {
  const Routes._();

  static const HOME = '/home';
  static const DETAIL = '/detail';
}
