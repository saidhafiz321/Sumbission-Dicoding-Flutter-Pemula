package com.example.dicoding_flutter_pemula_submission

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
